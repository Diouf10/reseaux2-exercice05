﻿using Microsoft.AspNetCore.SignalR;

namespace exercice05
{
    /// <summary>
    /// @author : Mouhammad Wagane Diouf
    /// </summary>
    public class VoteHub : Hub
    {
        private static Dictionary<string, int> games = new Dictionary<string, int>
        {
            { "sport", 0 },
            { "rpg", 0 },
            { "fps", 0 },
            { "platformer", 0 }
        };

       


        /// <summary>
        /// L'envoie d'un vote
        /// </summary>
        /// <param name="user"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public async Task SendVote(string categorie)
        {

            //Console.WriteLine($"Vote reçu pour la catégorie : {categorie}");

            if (games.ContainsKey(categorie))
            {
                games[categorie]++;
            }

            await Clients.All.SendAsync("ReceiveVote", categorie, games[categorie]);
        }
    }
}
